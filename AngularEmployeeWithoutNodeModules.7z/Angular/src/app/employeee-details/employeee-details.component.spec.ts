import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeeDetailsComponent } from './employeee-details.component';

describe('EmployeeeDetailsComponent', () => {
  let component: EmployeeeDetailsComponent;
  let fixture: ComponentFixture<EmployeeeDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeeDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeeDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
