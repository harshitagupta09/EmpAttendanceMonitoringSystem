import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';
import { Employee } from 'src/model/Employee';

@Component({
  selector: 'app-lop',
  templateUrl: './lop.component.html',
  styleUrls: ['./lop.component.css']
})
export class LopComponent implements OnInit {
  id: any;
  lop: any;
  //demo: number;
  employee: Employee;
  constructor(private router: Router, private service: EmployeeService) {
    this.employee = new Employee();
  }

  ngOnInit() {

    this.viewLop();
  }
  viewLop() {
    this.id = sessionStorage.getItem('id');
    console.log(this.id);
    this.service.viewLop(this.id).subscribe(res => {
      console.log("abcd");
      this.employee.id =this.id;
      this.employee.lop = res;
      //this.demo = res as number;
      console.log(this.employee.lop);

    })
  }


}
