import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { CreateEmployeeComponent } from './create-employee/create-employee.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { EmployeeeDetailsComponent } from './employeee-details/employeee-details.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { AdminComponent } from './admin/admin.component';
import { AdminStaffComponent } from './admin-staff/admin-staff.component';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeeloginComponent } from './employeelogin/employeelogin.component';
import { AttendanceComponent } from './attendance/attendance.component';
import { LopComponent } from './lop/lop.component';
import { LeaveComponent } from './leave/leave.component';


const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  //  { path: '', redirectTo: 'employee', pathMatch: 'full' },
  { path: 'home', component: HomeComponent, pathMatch: 'full' },
  { path: 'login', component: LoginComponent, pathMatch: 'full' },
  { path: 'employees', component: EmployeeListComponent, pathMatch: 'full' },
  { path: 'add', component: CreateEmployeeComponent, pathMatch: 'full' },
  { path: 'admin', component: AdminComponent, pathMatch: 'full' },
  { path: 'update/:id', component: UpdateEmployeeComponent, pathMatch: 'full' },
  { path: 'admin-staff', component: AdminStaffComponent, pathMatch: 'full' },
  { path: 'emp', component: EmployeeComponent, pathMatch: 'full' },
  { path: 'empLogin', component: EmployeeloginComponent, pathMatch: 'full' },
  { path: 'attendance', component: AttendanceComponent, pathMatch: 'full' },
  { path: 'lop', component: LopComponent, pathMatch: 'full' },
  { path: 'leave', component: LeaveComponent, pathMatch: 'full' },
  { path: '**', redirectTo: '/home', pathMatch: 'full' },
  { path: 'details/:id', component: EmployeeeDetailsComponent, pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
