import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from 'src/model/Employee';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  private page:number=0;
  private employeeDetailss:Array<Employee>;
  private pages:Array<number>;
  private EmployeeDetails=new Employee();
  employees: Observable<Employee[]>;
  searchText;
  constructor(private employeeService: EmployeeService,
    private router: Router) { }

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
     this.employeeService.getallEmployees(this.page).subscribe((employeeDetails)=>{
       console.log(employeeDetails);
        this.employeeDetailss=employeeDetails['content'];
        console.log(this.employeeDetailss);
        this.pages=new Array(employeeDetails['totalPages']);
        console.log(this.pages);
        
    });
   
  }
  setPage(i,event:any){
    event.preventDefault();
         this.page=i;
         this.ngOnInit();
  }

  deleteEmployee(id: number) {
    var v= confirm("Are u sure?");  
    if(v==true){  
    ("ok");  
    
      
    
    this.employeeService.deleteEmployee(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
         
        error => console.log(error));
      }  
     
  }
  

  employeeDetails(id: number){
    this.router.navigate(['details', id]);
  }

  updateEmployee(id: number,employee: Employee){
    this.router.navigate(['update',id,employee]);
  }
}
