import { ArraySortPipePipe } from './array-sort-pipe.pipe';

describe('ArraySortPipePipe', () => {
  it('create an instance', () => {
    const pipe = new ArraySortPipePipe();
    expect(pipe).toBeTruthy();
  });
});
